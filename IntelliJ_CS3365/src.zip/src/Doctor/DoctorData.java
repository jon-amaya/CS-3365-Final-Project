package Doctor;

public class DoctorData {
}
