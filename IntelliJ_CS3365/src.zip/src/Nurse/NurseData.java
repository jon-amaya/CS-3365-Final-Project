package Nurse;

public class NurseData {
}
