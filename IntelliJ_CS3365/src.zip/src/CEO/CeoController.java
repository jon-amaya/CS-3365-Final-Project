package CEO;

public class CeoController {
}
