package CEO;

public class CeoData {
}
